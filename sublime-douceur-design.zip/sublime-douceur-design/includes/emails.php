<?php
/**
 * Sublime Douceur — e-mails : routine du diagnostic, bienvenue (avec accord), après achat.
 * Envoi par wp_mail (WP Mail SMTP). Désinscription en un clic dans chaque e-mail.
 */
if (!defined('ABSPATH')) exit;

function sdd_subs() { $s = get_option('sdd_subs', []); return is_array($s) ? $s : []; }
function sdd_optout($email) { $o = get_option('sdd_optout', []); return is_array($o) && in_array(strtolower($email), $o, true); }
function sdd_token($email) { return hash_hmac('sha256', strtolower($email), wp_salt('auth')); }
function sdd_unsub_url($email) { return add_query_arg(['sdd_unsub' => rawurlencode($email), 't' => sdd_token($email)], home_url('/')); }

function sdd_mail_html($email, $title, $body, $cta = null, $cards = []) {
	$c = '';
	foreach ($cards as $id) {
		$p = sdd_p($id); if (!$p) continue;
		$c .= '<tr><td style="padding:8px 0"><a href="' . esc_url($p['u']) . '" style="text-decoration:none;color:#22261D"><img src="' . esc_url($p['i']) . '" width="72" height="72" alt="" style="border-radius:10px;vertical-align:middle;margin-right:14px;object-fit:cover"><b>' . esc_html($p['n']) . '</b> · ' . ($p['v'] ? 'dès ' : '') . esc_html(sdd_eur($p['p'])) . '</a></td></tr>';
	}
	$btn = $cta ? '<p style="margin:26px 0"><a href="' . esc_url($cta[1]) . '" style="background:#3E4A32;color:#F4F2EC;padding:14px 26px;border-radius:999px;text-decoration:none;font-weight:600;display:inline-block">' . esc_html($cta[0]) . '</a></p>' : '';
	return '<!doctype html><html lang="fr"><body style="margin:0;background:#F4F2EC;font-family:Helvetica,Arial,sans-serif;color:#22261D"><table width="100%" cellpadding="0" cellspacing="0" style="background:#F4F2EC"><tr><td align="center" style="padding:28px 14px"><table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#fff;border-radius:16px"><tr><td style="padding:34px 32px 10px;font-family:Georgia,serif;font-size:22px;color:#3E4A32">Sublime Douceur</td></tr><tr><td style="padding:6px 32px 30px;font-size:15px;line-height:1.6"><h1 style="font-family:Georgia,serif;font-weight:400;font-size:26px;line-height:1.2;margin:10px 0 18px">' . esc_html($title) . '</h1>' . $body . ($c ? '<table cellpadding="0" cellspacing="0" style="margin-top:14px">' . $c . '</table>' : '') . $btn . '<p style="margin-top:28px">Belle journée,<br>Nayette, Sublime Douceur</p></td></tr></table><p style="font-size:12px;color:#5C6253;margin:18px 0 0;max-width:560px">Sublime Douceur · <a href="' . esc_url(home_url('/')) . '" style="color:#5C6253">sublimedouceur.fr</a> · contact@sublimedouceur.fr<br><a href="' . esc_url(sdd_unsub_url($email)) . '" style="color:#5C6253">Ne plus recevoir ces e-mails</a></p></td></tr></table></body></html>';
}
function sdd_send($email, $subject, $title, $body, $cta = null, $cards = []) {
	if (!is_email($email)) return false;
	return wp_mail($email, $subject, sdd_mail_html($email, $title, $body, $cta, $cards), ['Content-Type: text/html; charset=UTF-8', 'Reply-To: Sublime Douceur <contact@sublimedouceur.fr>']);
}

/* ---------- Désinscription ---------- */
add_action('template_redirect', function () {
	if (empty($_GET['sdd_unsub'])) return;
	$email = strtolower(sanitize_email(wp_unslash($_GET['sdd_unsub'])));
	$t = isset($_GET['t']) ? sanitize_text_field(wp_unslash($_GET['t'])) : '';
	if ($email && hash_equals(sdd_token($email), $t)) {
		$o = get_option('sdd_optout', []); if (!is_array($o)) $o = [];
		if (!in_array($email, $o, true)) { $o[] = $email; update_option('sdd_optout', $o, false); }
		$s = sdd_subs(); unset($s[$email]); update_option('sdd_subs', $s, false);
		wp_die('<h1 style="font-family:Georgia,serif;font-weight:400">C’est noté.</h1><p>Vous ne recevrez plus nos e-mails. Vos commandes restent bien sûr confirmées par e-mail.</p><p><a href="' . esc_url(home_url('/')) . '">Retour à Sublime Douceur</a></p>', 'Désinscription', ['response' => 200]);
	}
	wp_die('Lien invalide.', 'Désinscription', ['response' => 400]);
});

/* ---------- Routine du diagnostic ---------- */
add_action('rest_api_init', function () {
	register_rest_route('sdd/v1', '/routine', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function ($r) {
		$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
		$k = 'sdd_rt_' . md5($ip); $n = (int) get_transient($k);
		if ($n >= 5) return new WP_REST_Response(['ok' => false, 'msg' => 'Trop de demandes, réessayez plus tard.'], 429);
		set_transient($k, $n + 1, HOUR_IN_SECONDS);
		if (trim((string) $r->get_param('site'))) return ['ok' => true]; // piège à robots
		$email = strtolower(sanitize_email((string) $r->get_param('email')));
		$prenom = sanitize_text_field((string) $r->get_param('prenom'));
		$ids = array_slice(array_filter(array_map('intval', (array) $r->get_param('ids'))), 0, 4);
		if (!is_email($email) || !$ids) return new WP_REST_Response(['ok' => false, 'msg' => 'Adresse e-mail invalide.'], 400);
		$hi = $prenom ? 'Bonjour ' . esc_html($prenom) . ',' : 'Bonjour,';
		$ok = sdd_send($email, 'Votre routine Sublime Douceur', 'Votre routine, en deux gestes.', '<p>' . $hi . '</p><p>Voici les soins que nous vous avons conseillés. Matin et soir : le savon ou le gel douche sous la douche, puis le lait corporel sur une peau encore légèrement humide.</p>', ['Retrouver ma routine', home_url('/guide-peaux-seches/')], $ids);
		if ($r->get_param('consent') && !sdd_optout($email)) {
			$s = sdd_subs();
			if (!isset($s[$email])) {
				$s[$email] = ['prenom' => $prenom, 'date' => current_time('mysql'), 'source' => 'diagnostic'];
				update_option('sdd_subs', $s, false);
				foreach ([2 => 'w2', 5 => 'w3', 9 => 'w4'] as $d => $type) wp_schedule_single_event(time() + $d * DAY_IN_SECONDS, 'sdd_mail_event', [$type, $email, $prenom]);
			}
		}
		return ['ok' => (bool) $ok];
	}]);
});

add_action('rest_api_init', function () {
	register_rest_route('sdd/v1', '/guide', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function ($r) {
		$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
		$k = 'sdd_gd_' . md5($ip); $n = (int) get_transient($k);
		if ($n >= 5) return new WP_REST_Response(['ok' => false, 'msg' => 'Trop de demandes, réessayez plus tard.'], 429);
		set_transient($k, $n + 1, HOUR_IN_SECONDS);
		if (trim((string) $r->get_param('site'))) return ['ok' => true];
		$email = strtolower(sanitize_email((string) $r->get_param('email')));
		$prenom = sanitize_text_field((string) $r->get_param('prenom'));
		if (!is_email($email)) return new WP_REST_Response(['ok' => false, 'msg' => 'Adresse e-mail invalide.'], 400);
		do_action('sdd_mail_event', 'g1', $email, $prenom);
		if (!sdd_optout($email)) {
			$s = sdd_subs();
			if (!isset($s[$email])) {
				$s[$email] = ['prenom' => $prenom, 'date' => current_time('mysql'), 'source' => 'guide'];
				update_option('sdd_subs', $s, false);
				foreach ([4 => 'w3', 8 => 'w4'] as $d => $type) wp_schedule_single_event(time() + $d * DAY_IN_SECONDS, 'sdd_mail_event', [$type, $email, $prenom]);
			}
		}
		return ['ok' => true];
	}]);
});

add_action('rest_api_init', function () {
	register_rest_route('sdd/v1', '/stats', ['methods' => 'GET', 'permission_callback' => function () { return current_user_can('manage_options'); }, 'callback' => function () {
		$s = sdd_subs(); $by = []; foreach ($s as $v) { $k = $v['source'] ?? '?'; $by[$k] = ($by[$k] ?? 0) + 1; }
		$week = 0; $lim = strtotime('-7 days', current_time('timestamp')); foreach ($s as $v) if (!empty($v['date']) && strtotime($v['date']) >= $lim) $week++;
		$o = get_option('sdd_optout', []);
		return ['inscrites' => count($s), 'par_source' => $by, 'nouvelles_7j' => $week, 'desinscrites' => is_array($o) ? count($o) : 0];
	}]);
});

/* ---------- Après achat (clientes, désinscription en un clic) ---------- */
add_action('woocommerce_order_status_completed', function ($order_id) {
	$o = wc_get_order($order_id); if (!$o || $o->get_meta('_sdd_follow')) return;
	$email = strtolower($o->get_billing_email()); if (!is_email($email)) return;
	$o->update_meta_data('_sdd_follow', 1); $o->save();
	wp_schedule_single_event(time() + 3 * DAY_IN_SECONDS, 'sdd_mail_event', ['p1', $email, $o->get_billing_first_name(), $order_id]);
	wp_schedule_single_event(time() + 10 * DAY_IN_SECONDS, 'sdd_mail_event', ['p2', $email, $o->get_billing_first_name(), $order_id]);
	wp_schedule_single_event(time() + 20 * DAY_IN_SECONDS, 'sdd_mail_event', ['p3', $email, $o->get_billing_first_name(), $order_id]);
	wp_schedule_single_event(time() + 45 * DAY_IN_SECONDS, 'sdd_mail_event', ['p4', $email, $o->get_billing_first_name(), $order_id]);
});

add_action('sdd_mail_event', function ($type, $email, $prenom = '', $order_id = 0) {
	if (sdd_optout($email)) return;
	$hi = '<p>' . ($prenom ? 'Bonjour ' . esc_html($prenom) . ',' : 'Bonjour,') . '</p>';
	$noel = current_time('timestamp') < strtotime(date('Y') . '-12-16 23:59:59');
	switch ($type) {
		case 'w2':
			sdd_send($email, 'Les 5 gestes qui assèchent la peau', 'Cinq gestes, sans qu’on y pense.', $hi . '<p>La douche trop chaude, trop longue, la serviette qui frotte, le lait corporel appliqué trop tard, les soins qu’on change sans cesse. Rien de grave, mais la peau tiraille.</p><p>Notre petit guide vous dit comment faire autrement.</p>', ['Lire le guide', home_url('/guide-peaux-seches/')]);
			break;
		case 'w3':
			sdd_send($email, 'D’où viennent nos savons', 'Du chaudron marseillais à votre peau.', $hi . '<p>Nos savons et notre gel douche viennent de la Savonnerie Le Sérail, qui cuit son savon au chaudron à Marseille depuis 1949. Le lait d’ânesse leur apporte sa douceur, connue depuis l’Antiquité.</p>', ['Notre histoire', home_url('/a-propos/')], [15, 27]);
			break;
		case 'w4':
			sdd_send($email, $noel ? 'Votre routine, prête à offrir' : 'Votre routine, en coffret', 'Prête à offrir.', $hi . '<p>Nos coffrets arrivent emballés, prêts à offrir.' . ($noel ? ' Commandez avant le 16 décembre : ils arrivent avant Noël.' : '') . ' Livraison offerte dès 39 € en point relais.</p>', ['Voir les idées cadeaux', home_url('/idees-cadeaux/')], [36, 51, 49]);
			break;
		case 'p1':
			sdd_send($email, 'Bien utiliser vos soins', 'Vos soins, au bon moment.', $hi . '<p>Merci pour votre commande. Trois conseils pour en profiter pleinement :</p><p>· Entre deux douches, laissez le savon sécher sur un porte-savon : il dure plus longtemps.<br>· Le lait corporel s’applique juste après la douche, sur une peau encore légèrement humide.<br>· Une eau tiède plutôt que chaude : la peau tiraille moins.</p><p>Une question ? Répondez simplement à cet e-mail.</p>');
			break;
		case 'g1':
			sdd_send($email, 'Votre guide : les 5 gestes qui assèchent la peau', 'Cinq gestes, sans qu’on y pense.', $hi . '<p>· La douche trop chaude : préférez une eau tiède.<br>· La douche trop longue : cinq minutes suffisent.<br>· La serviette qui frotte : tamponnez plutôt.<br>· Le lait corporel appliqué trop tard : juste après la douche, sur une peau encore humide.<br>· Les soins qu’on change sans cesse : la peau aime la constance.</p><p>Le guide complet, avec la routine en deux gestes :</p>', ['Lire le guide', home_url('/guide-peaux-seches/')], [15, 29]);
			break;
		case 'p3':
			$have = []; $o = $order_id ? wc_get_order($order_id) : null; if ($o) foreach ($o->get_items() as $it) $have[] = (int) $it->get_product_id();
			$sug = array_values(array_diff([29, 15, 27, 51, 31], $have)); $sug = array_slice($sug, 0, 3);
			if ($sug) sdd_send($email, 'Pour compléter votre routine', 'Les soins qui vont avec.', $hi . '<p>Le savon lave sans dessécher, le lait corporel garde la douceur après la douche. Voici ce qui complète vos soins :</p>', ['Voir tous les soins', home_url('/boutique/')], $sug);
			break;
		case 'p4':
			sdd_send($email, 'Votre savon touche à sa fin ?', 'Le moment de faire le plein.', $hi . '<p>Si votre savon commence à s’amenuiser, vos soins vous attendent, livrés en 3 à 5 jours ouvrés. Livraison offerte dès 39 € en point relais.</p>', ['Retrouver mes soins', home_url('/boutique/')], [15, 13, 29]);
			break;
		case 'p2':
			sdd_send($email, 'Votre avis compte', 'Qu’en pensez-vous ?', $hi . '<p>Quelques jours ont passé : vos soins vous plaisent-ils ?</p><p>Répondez à cet e-mail en quelques mots, avec vos propres mots. Si vous l’acceptez, nous publierons votre avis sur le site avec votre prénom et votre ville : dites-le-nous simplement dans votre réponse.</p>', null, [29, 15, 36]);
			break;
	}
}, 10, 4);
