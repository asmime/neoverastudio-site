(function(){
document.documentElement.classList.add('sdd-js');
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const D=window.SDD||{products:[]},PR=D.products||[];
const byId=id=>PR.find(p=>+p.id===+id);
const fmt=x=>(Math.round(x*100)/100).toFixed(2).replace('.',',')+' €';
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const IC_PLUS='<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>';
const toast=m=>{const t=$('#sdToast');if(!t)return;t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),2600)};
/* bandeau */
const top=$('#sdTop');if(top){const d=Math.ceil((new Date(new Date().getFullYear(),11,16)-new Date())/864e5);if(d>0)top.innerHTML='Livré avant Noël pour toute commande avant le <b>16 décembre</b> · encore <b>'+d+' jours</b>';else top.innerHTML='Savons de Marseille et soins au lait d’ânesse · livraison offerte dès <b>39 €</b> en point relais'}
addEventListener('scroll',()=>{const h=$('#sdHd');if(h)h.classList.toggle('sc',scrollY>8)},{passive:true});
/* menu */
const menu=$('#sdMenu');const closeMenu=()=>{if(menu){menu.classList.remove('open');menu.setAttribute('aria-hidden','true')}};
if($('#sdBurger'))$('#sdBurger').onclick=()=>{menu.classList.add('open');menu.setAttribute('aria-hidden','false')};
if($('#sdMenuX'))$('#sdMenuX').onclick=closeMenu;
/* ---------- panier (Store API) ---------- */
let NONCE='',CART=null;
async function api(path,opt={}){const h={'Content-Type':'application/json'};if(NONCE)h.Nonce=NONCE;const r=await fetch(D.store+path,Object.assign({credentials:'same-origin',headers:h},opt));const n=r.headers.get('Nonce');if(n)NONCE=n;const j=await r.json().catch(()=>null);if(!r.ok)throw j||{};return j}
const money=(v,c)=>+v/Math.pow(10,c.currency_minor_unit||2);
async function loadCart(){try{CART=await api('cart');renderCart()}catch(e){}}
function renderCart(){if(!CART)return;const n=CART.items_count||0;const b=$('#sdCartN');if(b){b.textContent=n;b.hidden=!n}
 const st=money(CART.totals.total_items,CART.totals)+(CART.totals.total_items_tax?money(CART.totals.total_items_tax,CART.totals):0);const left=Math.max(0,39-st);
 const P=$('#sdProg');if(P)P.innerHTML=(left>0?'Plus que <b>'+fmt(left)+'</b> pour la livraison offerte en point relais':'<b>Livraison offerte en point relais</b>')+'<div class="bar"><i style="width:'+Math.min(100,st/39*100)+'%"></i></div>';
 const Ls=$('#sdLines');if(Ls)Ls.innerHTML=CART.items.length?CART.items.map(it=>{const meta=(it.item_data||[]).map(d=>esc(d.name||d.key)+' : '+esc(d.value||d.display)).concat((it.variation||[]).map(v=>esc(v.value))).join(' · ');return `<div class="line"><img src="${esc((it.images[0]||{}).thumbnail||'')}" alt=""><div><b>${it.name}</b>${meta?`<small>${meta}</small>`:''}<div class="q"><button data-dq="${it.key}" data-q="${it.quantity}" aria-label="Retirer un">−</button><span>${it.quantity}</span><button data-iq="${it.key}" data-q="${it.quantity}" aria-label="Ajouter un">+</button></div></div><div style="text-align:right"><b>${fmt(money(it.totals.line_subtotal,it.totals)+money(it.totals.line_subtotal_tax||0,it.totals))}</b><button class="sd-link" style="font-size:.8rem;font-weight:500;display:block;margin-left:auto" data-rm="${it.key}">Retirer</button></div></div>`}).join(''):`<div class="empty"><p>Votre panier est vide.</p><a class="sdd-btn" href="${D.shop}">Découvrir les soins</a></div>`;
 const df=$('#sdDf');if(df)df.hidden=!CART.items.length;const s=$('#sdSub');if(s)s.textContent=fmt(st);upsell(st)}
function upsell(st){const Ls=$('#sdLines');if(!Ls||!CART.items.length)return;const have=CART.items.map(i=>+i.id);
 const pick=(()=>{const order=have.includes(29)?[15,13,27]:have.some(i=>[13,15,17,19,21,23,25].includes(i))?[29,27]:have.includes(27)?[29,15]:have.some(i=>[36,51,49,45,40,150].includes(i))?[13,15,29]:[15,29];const left=39-st;
  const c=order.map(byId).filter(p=>p&&!p.v&&!D.pick.includes(p.id)&&!have.includes(p.id));if(left>0){const f=c.find(p=>p.p>=left);if(f)return f}return c[0]})();
 if(!pick)return;const left=39-st;const d=document.createElement('div');d.className='sd-ups';
 d.innerHTML=`<small>${left>0&&pick.p>=left?'Avec ce soin, la livraison devient offerte':'Souvent pris avec'}</small><div class="rec"><img src="${esc(pick.i)}" alt=""><div><b>${esc(pick.n)}</b><small>${fmt(pick.p)}</small></div><button class="add" data-quick="${pick.id}" aria-label="Ajouter au panier">${IC_PLUS}</button></div>`;Ls.appendChild(d)}
async function addItem(id,qty=1){try{if(!NONCE)await loadCart();CART=await api('cart/add-item',{method:'POST',body:JSON.stringify({id:+id,quantity:qty})});renderCart();openCart();document.body.dispatchEvent(new Event('wc-blocks_added_to_cart'))}catch(e){location.href=(byId(id)||{}).u||D.shop}}
function quick(id){const p=byId(id);if(!p)return;if(p.v||D.pick.includes(+id)){location.href=p.u;return}addItem(id)}
const openCart=()=>{const d=$('#sdDrawer');if(!d)return;d.classList.add('on');$('#sdOv').classList.add('on');document.body.classList.add('sd-lock');closeMenu();renderCart()};
const closeCart=()=>{$('#sdDrawer')?.classList.remove('on');$('#sdOv')?.classList.remove('on');document.body.classList.remove('sd-lock')};
if($('#sdCartB'))$('#sdCartB').onclick=()=>{openCart();loadCart()};
if($('#sdOv'))$('#sdOv').onclick=closeCart;if($('#sdDrX'))$('#sdDrX').onclick=closeCart;
document.addEventListener('click',async e=>{const t=e.target.closest('[data-quick],[data-dq],[data-iq],[data-rm]');if(!t)return;e.preventDefault();
 try{if(t.dataset.quick)return quick(t.dataset.quick);
 if(t.dataset.rm){CART=await api('cart/remove-item',{method:'POST',body:JSON.stringify({key:t.dataset.rm})})}
 if(t.dataset.dq){const q=+t.dataset.q-1;CART=q<1?await api('cart/remove-item',{method:'POST',body:JSON.stringify({key:t.dataset.dq})}):await api('cart/update-item',{method:'POST',body:JSON.stringify({key:t.dataset.dq,quantity:q})})}
 if(t.dataset.iq){CART=await api('cart/update-item',{method:'POST',body:JSON.stringify({key:t.dataset.iq,quantity:+t.dataset.q+1})})}
 renderCart()}catch(x){toast('Un souci est survenu, réessayez.')}});
loadCart();
/* ouvrir le tiroir après un ajout classique (fiche produit) */
if(document.querySelector('.woocommerce-message a.wc-forward')&&!/panier|cart|commande|checkout/.test(location.pathname)){setTimeout(()=>{loadCart().then(openCart)},300)}
/* ---------- Pour qui ---------- */
const WHO={maman:[36,'Pour celle qui vous a toujours chouchoutée : le rituel complet, prêt à offrir.'],mamie:[51,'Une peau plus fine demande un soin riche : le trio réconfort.'],amie:[45,'Un vrai cadeau, à petit prix : deux savons et un soin.'],soeur:[49,'De la douche à l’hydratation, le duo qu’elle gardera.'],homme:[150,'Utile et élégant : trois savons et un pot de karité, dans sa barque.'],collegue:[40,'Six savons de Marseille à partager… ou pas.'],moi:[15,'Commencez par notre savon le plus riche.']};
function showPick(k){const el=$('#sdPick');if(!el)return;const p=byId(WHO[k][0]);if(!p)return;el.innerHTML=`<img src="${esc(p.i)}" alt="${esc(p.n)}"><div><h3>${esc(p.n)}</h3><p>${WHO[k][1]}</p><div class="row"><span class="pr">${p.v?'dès ':''}${fmt(p.p)}</span><button class="sdd-btn light" data-quick="${p.id}">Ajouter au panier</button><a class="sd-link" style="color:#fff" href="${esc(p.u)}">Voir le détail</a></div></div>`}
document.addEventListener('click',e=>{const c=e.target.closest('[data-who]');if(!c)return;$$('[data-who]').forEach(x=>x.setAttribute('aria-pressed','false'));c.setAttribute('aria-pressed','true');showPick(c.dataset.who)});
showPick('maman');
const v=$('#sdVid');if(v){v.muted=true;v.play().catch(()=>{});v.addEventListener('error',()=>v.remove())}
/* révélation */
const io='IntersectionObserver' in window?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.08}):null;$$('.rv').forEach(el=>io?io.observe(el):el.classList.add('in'));
/* ---------- choix des savons ---------- */
const six=$('#sdSix');
if(six){const form=six.closest('form');const S={};const cnt=$('#sdCnt');const btn=form&&form.querySelector('.single_add_to_cart_button');
 const isChoose=()=>{const sel=form.querySelector('.variations select');return sel&&/choisi/i.test(sel.options[sel.selectedIndex]?.text||'')};
 const upd=()=>{const n=Object.values(S).reduce((a,b)=>a+b,0);Object.keys(S).forEach(k=>{});$$('[data-six]').forEach(el=>{const id=el.dataset.six;$('#s6'+id).textContent=S[id]||0;el.classList.toggle('on',!!S[id])});
  six.hidden=!isChoose();$('#sdd_six').value=Object.entries(S).filter(x=>x[1]).map(x=>x[0]+'x'+x[1]).join(',');
  cnt.classList.remove('err');cnt.textContent=n<6?'Encore '+(6-n)+' à choisir':'Votre sélection est complète'};
 six.addEventListener('click',e=>{const b=e.target.closest('[data-s6]');if(!b)return;e.preventDefault();const id=b.dataset.s6.slice(1),n=Object.values(S).reduce((a,c)=>a+c,0);if(b.dataset.s6[0]==='+'&&n<6)S[id]=(S[id]||0)+1;if(b.dataset.s6[0]==='-'&&S[id])S[id]--;upd()});
 form.addEventListener('change',upd);if(window.jQuery)jQuery(form).on('found_variation reset_data',upd);
 form.addEventListener('submit',e=>{if(isChoose()&&Object.values(S).reduce((a,b)=>a+b,0)!==6){e.preventDefault();cnt.textContent='Choisissez vos 6 savons';cnt.classList.add('err');six.scrollIntoView({block:'center',behavior:'smooth'})}});
 upd()}
const one=$('#sdd_one');
if(one){one.closest('.sd-opt').addEventListener('click',e=>{const b=e.target.closest('[data-one]');if(!b)return;e.preventDefault();one.value=b.dataset.one;$$('[data-one]').forEach(x=>x.classList.toggle('on',x===b))})}
/* ---------- Sublime Conseil ---------- */
const adv=$('#sdAdv'),msgs=$('#sdMsgs');if(!adv)return;
const say=(t,w='a')=>{const d=document.createElement('div');d.className='msg '+w;d.innerHTML=t;msgs.appendChild(d);msgs.scrollTop=msgs.scrollHeight};
const recs=ids=>{ids.forEach(id=>{const p=byId(id);if(!p)return;const d=document.createElement('div');d.className='rec';d.innerHTML=`<img src="${esc(p.i)}" alt=""><div><a href="${esc(p.u)}" style="text-decoration:none"><b>${esc(p.n)}</b></a><small>${p.v?'dès ':''}${fmt(p.p)}</small></div><button class="add" data-quick="${p.id}" aria-label="Ajouter au panier">${IC_PLUS}</button>`;msgs.appendChild(d)});msgs.scrollTop=msgs.scrollHeight};
const choices=arr=>{const d=document.createElement('div');d.className='ch';arr.forEach(([l,f])=>{const b=document.createElement('button');b.type='button';b.textContent=l;b.onclick=()=>{d.remove();say(esc(l),'u');setTimeout(f,250)};d.appendChild(b)});msgs.appendChild(d);msgs.scrollTop=msgs.scrollHeight};
const XMAS='Commandez avant le 16 décembre : votre colis arrive avant Noël, prêt à offrir. Livraison offerte dès 39 € en point relais.';
const menuA=()=>choices([['Mon diagnostic peau',diag],['Trouver un cadeau',gift],['Pour ma peau',skin],['Mon budget',bud],['Livraison avant Noël',()=>{say(XMAS);recs([36]);more()}]]);
const more=()=>setTimeout(()=>{say('Autre chose ?');menuA()},500);
const WR={maman:[36],mamie:[51,29],amie:[45,49],soeur:[49,36],homme:[150,15],collegue:[40],moi:[15,29]},WL={maman:'Ma maman',mamie:'Ma grand-mère',amie:'Une amie',soeur:'Ma sœur',homme:'Un homme',collegue:'Une collègue',moi:'Pour moi'};
function gift(){say('Pour qui ?');choices(Object.keys(WL).map(k=>[WL[k],()=>{say(WHO[k][1]);recs(WR[k]);more()}]))}
function skin(){say('Quel est votre type de peau ?');choices([['Sèche',[15,29,31],'Un nettoyant surgras puis un soin riche :'],['Sensible',[13,21,15],'Les plus doux pour les peaux réactives :'],['Mixte',[25,21],'Pour purifier sans agresser :'],['Normale',[13,17,27],'Pour une toilette douce au quotidien :']].map(([l,ids,t])=>[l,()=>{say(t);recs(ids);more()}]))}
function bud(){say('Quel budget ?');choices([['Moins de 10 €',()=>{say('Voici mes idées :');recs([15,13,31]);more()}],['De 10 à 25 €',()=>{say('Voici mes idées :');recs([45,49,29]);more()}],['De 25 à 40 €',()=>{say('Voici mes idées :');recs([36,51,40]);more()}]])}

/* ---------- Diagnostic peau ---------- */
function diag(){const A={};say('Trois questions, et je vous propose votre routine.');say('Votre peau est plutôt…');
 choices([['Sèche',()=>q2('seche')],['Sensible',()=>q2('sensible')],['Mixte ou normale',()=>q2('mixte')],['Mature',()=>q2('mature')]]);
 function q2(t){A.t=t;say('Ce qui vous gêne le plus ?');choices([['Elle tiraille',()=>q3('tiraille')],['Rougeurs ou démangeaisons',()=>q3('rougeurs')],['Un manque de confort',()=>q3('confort')]])}
 function q3(g){A.g=g;say('Sous la douche, vous préférez…');choices([['Le savon',()=>res('savon')],['Le gel douche',()=>res('gel')]])}
 function res(f){const base={seche:15,sensible:13,mixte:21,mature:19}[A.t];let ids=[f==='gel'?27:base,29];ids=ids.filter(i=>{const p=byId(i);return p&&!p.v});
  if(A.g==='rougeurs')say('Sur une peau qui réagit, faites d’abord un essai sur une petite zone. Si les rougeurs persistent, demandez l’avis de votre médecin.');
  say('Votre routine :');recs(ids);const tot=ids.reduce((a,i)=>a+((byId(i)||{}).p||0),0);
  const b=document.createElement('button');b.className='sdd-btn full';b.style.marginTop='10px';b.textContent='Ajouter ma routine · '+fmt(tot);
  b.onclick=async()=>{b.disabled=true;try{if(!NONCE)await loadCart();for(const i of ids)CART=await api('cart/add-item',{method:'POST',body:JSON.stringify({id:i,quantity:1})});renderCart();openCart();document.body.dispatchEvent(new Event('wc-blocks_added_to_cart'))}catch(e){b.disabled=false}};
  msgs.appendChild(b);
  const mf=document.createElement('form');mf.className='sd-mailf';mf.innerHTML='<b>Recevoir ma routine par e-mail</b><input name="prenom" placeholder="Prénom" autocomplete="given-name"><input name="email" type="email" required placeholder="Adresse e-mail" autocomplete="email"><input name="site" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true"><label><input type="checkbox" name="consent"> Je veux aussi recevoir quelques conseils et nouveautés. Désinscription en un clic.</label><button class="sdd-btn full">Envoyer</button>';
  mf.onsubmit=async ev=>{ev.preventDefault();const fd=new FormData(mf);const bt=mf.querySelector('button');bt.disabled=true;try{const r=await fetch(D.routine,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prenom:fd.get('prenom'),email:fd.get('email'),site:fd.get('site'),consent:!!fd.get('consent'),ids})});const j=await r.json();mf.innerHTML=j.ok?'<b>C’est envoyé.</b> Pensez à regarder dans vos courriers indésirables.':'<b>'+(j.msg||'Un souci est survenu.')+'</b>'}catch(x){bt.disabled=false}};
  msgs.appendChild(mf);msgs.scrollTop=msgs.scrollHeight;if(A.t==='seche'&&f==='savon')say('Astuce : le lot Peaux sèches réunit savon surgras, gel douche et lait corporel, 2 € de moins qu’à l’unité.');more()}}
document.addEventListener('click',e=>{const t=e.target.closest('[data-diag]');if(!t)return;e.preventDefault();openAdv();diag()});
document.addEventListener('click',async e=>{const t=e.target.closest('[data-addall]');if(!t)return;e.preventDefault();t.disabled=true;try{if(!NONCE)await loadCart();for(const i of t.dataset.addall.split(','))CART=await api('cart/add-item',{method:'POST',body:JSON.stringify({id:+i,quantity:1})});renderCart();openCart();document.body.dispatchEvent(new Event('wc-blocks_added_to_cart'))}catch(x){}t.disabled=false});
(()=>{const f=document.getElementById('sdLeadF');if(!f)return;f.onsubmit=async e=>{e.preventDefault();const fd=new FormData(f);const b=f.querySelector('button');b.disabled=true;try{const r=await fetch(D.guide,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prenom:fd.get('prenom'),email:fd.get('email'),site:fd.get('site')})});const x=await r.json();f.innerHTML=x.ok?'<p class="ok"><b>C’est envoyé.</b> Regardez aussi dans vos courriers indésirables.</p>':'<p class="ok">'+(x.msg||'Un souci est survenu.')+'</p>'}catch(z){b.disabled=false}}})();
let started=false;const start=()=>{if(started)return;started=true;say('Bonjour, je suis Sublime Conseil. Je vous aide à trouver le bon soin ou le bon cadeau.');menuA()};
const openAdv=()=>{start();adv.classList.add('on');$('#sdBub').hidden=true;try{sessionStorage.setItem('sd_bub','1')}catch(e){}$('#sdAdvI').focus()};
$('#sdAdvB').onclick=openAdv;$('#sdAdvX').onclick=()=>adv.classList.remove('on');$('#sdBub').onclick=openAdv;
$('#sdBubX').onclick=e=>{e.stopPropagation();$('#sdBub').hidden=true;try{sessionStorage.setItem('sd_bub','1')}catch(x){}};
addEventListener('keydown',e=>{if(e.key==='Escape'){adv.classList.remove('on');closeCart();closeMenu()}});
let bubDone=false;const maybeBub=()=>{if(bubDone)return;let s;try{s=sessionStorage.getItem('sd_bub')}catch(e){}if(s||adv.classList.contains('on')||document.body.classList.contains('sd-lock'))return;if(document.body.classList.contains('single-product')||/commande|checkout|panier|cart/.test(location.pathname))return;const h=$('.sd-hero');if(h&&h.getBoundingClientRect().bottom>innerHeight*.4)return;bubDone=true;try{sessionStorage.setItem('sd_bub','1')}catch(e){}const bb=$('#sdBub');bb.hidden=false;const y0=scrollY;const hide=()=>{bb.hidden=true;removeEventListener('scroll',onS)};const onS=()=>{if(Math.abs(scrollY-y0)>120)hide()};setTimeout(()=>addEventListener('scroll',onS,{passive:true}),600);setTimeout(hide,7000)};
addEventListener('scroll',maybeBub,{passive:true});setTimeout(maybeBub,8000);
const hero=$('.sd-hero'),ab=$('#sdAdvB');if(hero&&ab&&'IntersectionObserver' in window){new IntersectionObserver(es=>es.forEach(e=>ab.classList.toggle('hide',e.isIntersecting&&e.intersectionRatio>.35)),{threshold:[0,.35,1]}).observe(hero)}
if(/commande|checkout/.test(location.pathname))ab.style.display='none';
$('#sdAdvF').onsubmit=e=>{e.preventDefault();start();const val=$('#sdAdvI').value.trim();if(!val)return;say(esc(val),'u');$('#sdAdvI').value='';
 const s=val.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
 setTimeout(()=>{
 if(/\b(1[7-9]|2\d|3[01])\s*(dec)/.test(s)){say('Après le 16 décembre, nous ne pouvons pas garantir une livraison avant Noël. Pour être sûre, commandez avant le 16.');recs([36]);return more()}
 const bm=s.match(/(\d{1,3})\s*(€|eur|euro)|€\s*(\d{1,3})|(moins de|max|budget|maximum)\s*(\d{1,3})/);
 if(bm){const b=+(bm[1]||bm[3]||bm[5]);const fem=/\b(mere|maman|femme|soeur|amie|mamie|copine|fille|elle|tante|belle-mere)\b/.test(s),mas=/\b(homme|mari|papa|pere|frere|fils|oncle)\b/.test(s);const l=PR.filter(p=>p.p<=b&&!(fem&&p.id===150)&&!(mas&&[36,49].includes(p.id))).sort((a,c)=>((c.c||[]).includes('coffrets')-(a.c||[]).includes('coffrets'))||c.p-a.p).slice(0,3);say('Jusqu’à '+b+' €, voici ce que je vous conseille :');recs(l.length?l.map(p=>p.id):[13,15]);return more()}
 const R=[[/(eczema|psoria|reacti|allerg)/,()=>{say('Sur une peau réactive ou en cas d’eczéma, faites d’abord un essai sur une petite zone et demandez l’avis de votre médecin. Les plus doux :');recs([13,21,15])}],
 [/\b(ouvert|entame)/,()=>say('Non : pour des raisons d’hygiène, seuls les produits non ouverts peuvent être retournés. Pour un souci avec un produit, écrivez à Nayette : contact@sublimedouceur.fr.')],
 [/(difference|surgras.*anesse|anesse.*surgras)/,()=>say('Le savon au lait d’ânesse (100 g) convient à toute la toilette. Le surgras (125 g, 72 % d’huile bio) est plus riche : le meilleur choix pour les peaux sèches et le visage.')],
 [/(belle-mere|belle mere|maman|mere|mamie|grand-mere|tante|marraine|maitresse|soeur|amie|femme|epouse|copine)/,()=>{say('Pour elle, le cadeau le plus offert :');recs([36,51])}],
 [/\b(bonjour|salut|hello|coucou)\b/,()=>{say('Bonjour ! Un cadeau, un type de peau, un budget ? Dites-moi.');menuA();return 1}],
 [/(merci)/,()=>{say('Avec plaisir. Belle journée !');return 1}],
 [/(bebe|nourrisson|enfant)/,()=>say('Nos soins sont des cosmétiques pour toute la famille. Pour la peau d’un bébé, demandez conseil à votre médecin avant tout usage.')],
 [/(etranger|belgique|suisse|international|europe)/,()=>say('Nous livrons en France uniquement pour le moment.')],
 [/(livr|delai|frais de port|expedi|colissimo|relais)/,()=>{say(XMAS);say('Point relais dès 4,90 €, offert dès 39 €. Colissimo à domicile dès 9,90 €. Livraison en 3 à 5 jours ouvrés.')}],
 [/(retour|rembours)/,()=>say('Vous avez 14 jours après réception pour changer d’avis, sur les produits non ouverts.')],
 [/\b(boutique|magasin|adresse|sur place|venir|retrait|passer vous voir)\b/,()=>say('Nos soins se commandent ici, en quelques clics : chaque colis est préparé avec soin et expédié de Marseille. Une question ? Nayette vous répond : contact@sublimedouceur.fr.')],  [/(paie|payer|carte|paypal)/,()=>say('Paiement par carte bancaire ou PayPal, entièrement sécurisé.')],
 [/(noel)/,()=>{say(XMAS);recs([36])}],
 [/\b(homme|mari|papa|pere|frere|barbe|rasage)\b/,()=>{say('Pour un homme :');recs([150,15])}],
 [/(visage)/,()=>{say('Pour le visage, notre savon surgras nettoie sans dessécher :');recs([15,13])}],
 [/\b(bio|naturel|fabrique|fabriques|composition|ingredient)/,()=>say('Le lait corporel est au lait frais d’ânesse bio, fabriqué en Provence. Nos savons sont cuits au chaudron à Marseille.')],
 [/(dure|combien de temps)/,()=>say('Un savon dure environ un mois en usage quotidien. Gardez-le au sec.')],
 [/(cadeau|offrir|coffret)/,()=>{say('Tous nos coffrets sont livrés prêts à offrir, emballage inclus :');recs([36,150,45])}],
 [/(seche|tiraill)/,()=>{say('Un nettoyant surgras puis un soin riche :');recs([15,29,51])}],
 [/(sensible)/,()=>{say('Les plus doux pour les peaux sensibles :');recs([13,21,15])}],
 [/(contact|telephone|email|mail|nayette|parler)/,()=>say('Écrivez à Nayette : contact@sublimedouceur.fr. Elle répond personnellement.')]];
 const h=R.find(x=>x[0].test(s));
 if(!h){say('Je réponds aux questions sur nos soins, nos cadeaux et la livraison. Pour tout le reste, Nayette vous répond : contact@sublimedouceur.fr.');menuA();return}
 if(!h[1]())more()},300)};
})();
