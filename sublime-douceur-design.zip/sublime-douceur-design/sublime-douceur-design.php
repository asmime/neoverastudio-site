<?php
/**
 * Plugin Name: Sublime Douceur — Design
 * Description: Nouvelle identité de sublimedouceur.fr (en-tête, pied de page, accueil, conseiller Sublime Conseil, choix des savons dans les coffrets). Désactiver l'extension rend au site son apparence précédente.
 * Version: 1.5.1
 * Author: Neovera Studio
 * Requires Plugins: woocommerce
 * Text Domain: sublime-douceur-design
 */
if (!defined('ABSPATH')) exit;
define('SDD_URL', plugin_dir_url(__FILE__));
define('SDD_VER', '1.5.1');
define('SDD_SOAPS', [13, 17, 19, 21, 23, 25]);
define('SDD_PICK6', 40); // Coffret Découverte
define('SDD_PICK1', 45); // Coffret Douceur
require_once __DIR__ . '/includes/emails.php';

/* ---------- Mode aperçu : visible seulement par l'administratrice tant que sdd_live = 0 ---------- */
add_action('init', function () {
	register_setting('general', 'sdd_live', ['type' => 'boolean', 'default' => false, 'show_in_rest' => true]);
});
function sdd_on() { return (bool) get_option('sdd_live') || current_user_can('edit_posts'); }
/* ---------- Assets ---------- */
add_action('wp_enqueue_scripts', function () {
	if (!sdd_on()) return;
	wp_enqueue_style('sdd', SDD_URL . 'assets/sd.css', [], SDD_VER);
	wp_enqueue_script('sdd', SDD_URL . 'assets/sd.js', [], SDD_VER, true);
	wp_localize_script('sdd', 'SDD', sdd_data());
}, 50);
add_action('wp_head', function () {
	if (!sdd_on()) return;
	echo '<link rel="preload" href="' . esc_url(SDD_URL . 'assets/fonts/gloock.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
	echo '<link rel="preload" href="' . esc_url(SDD_URL . 'assets/fonts/manrope-400.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
	echo '<meta name="theme-color" content="#3E4A32">' . "\n";
}, 1);
add_filter('body_class', function ($c) { if (sdd_on()) $c[] = 'sdd'; return $c; });

function sdd_products() {
	static $out = null;
	if ($out !== null) return $out;
	$out = [];
	if (!function_exists('wc_get_products')) return $out;
	foreach (wc_get_products(['status' => 'publish', 'limit' => 100]) as $p) {
		$cats = wp_get_post_terms($p->get_id(), 'product_cat', ['fields' => 'slugs']);
		$img = wp_get_attachment_image_url($p->get_image_id(), 'woocommerce_thumbnail') ?: wc_placeholder_img_src();
		$price = (float) ($p->is_type('variable') ? $p->get_variation_price('min') : $p->get_price());
		if ((int) $p->get_id() === 51) $img = SDD_URL . 'assets/p51.jpg';
		$out[] = [
			'id' => $p->get_id(), 'n' => html_entity_decode(wp_strip_all_tags($p->get_name()), ENT_QUOTES, 'UTF-8'), 'p' => $price,
			'v' => $p->is_type('variable'), 'u' => get_permalink($p->get_id()), 'i' => $img, 'c' => $cats,
			's' => $p->is_in_stock(),
		];
	}
	return $out;
}
function sdd_data() {
	return [
		'products' => sdd_products(),
		'store' => esc_url_raw(rest_url('wc/store/v1/')),
		'cart' => function_exists('wc_get_cart_url') ? wc_get_cart_url() : '/panier/',
		'checkout' => function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : '/commande/',
		'shop' => function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '/boutique/',
		'pick' => [SDD_PICK6, SDD_PICK1],
		'asset' => SDD_URL . 'assets/',
		'home' => home_url('/'),
		'routine' => esc_url_raw(rest_url('sdd/v1/routine')),
		'guide' => esc_url_raw(rest_url('sdd/v1/guide')),
	];
}
function sdd_p($id) { foreach (sdd_products() as $p) if ((int) $p['id'] === (int) $id) return $p; return null; }
function sdd_eur($x) { return number_format((float) $x, 2, ',', ' ') . ' €'; }
function sdd_card($id, $extra = '') {
	$p = sdd_p($id); if (!$p) return '';
	$star = ((int) $id === 36) ? '<span class="tag">Le plus offert</span>' : '';
	return '<article class="card ' . $extra . '"><a class="ph" href="' . esc_url($p['u']) . '"><img src="' . esc_url($p['i']) . '" alt="' . esc_attr($p['n']) . '" loading="lazy" width="600" height="600">' . $star . '</a><h3><a href="' . esc_url($p['u']) . '">' . esc_html($p['n']) . '</a></h3><div class="meta"><span class="pr">' . ($p['v'] ? 'dès ' : '') . sdd_eur($p['p']) . '</span><button class="add" data-quick="' . (int) $id . '" aria-label="Ajouter au panier : ' . esc_attr($p['n']) . '"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></button></div></article>';
}
function sdd_img($file) { $u = wp_upload_dir(); return $u['baseurl'] . '/' . $file; }

/* ---------- En-tête, bandeau, pied, conseiller ---------- */
add_action('wp_body_open', function () {
	if (!sdd_on()) return;
	$nav = [['Nos soins', home_url('/boutique/')], ['Idées cadeaux', home_url('/idees-cadeaux/')], ['Le lait d’ânesse', home_url('/le-lait-d-anesse/')], ['Notre histoire', home_url('/a-propos/')], ['Questions', home_url('/faq/')]];
	$links = ''; foreach ($nav as $n) $links .= '<a href="' . esc_url($n[1]) . '">' . esc_html($n[0]) . '</a>';
	$ane = sdd_ane();
	echo '<div class="sd-top" id="sdTop">Livré avant Noël pour toute commande avant le <b>16 décembre</b></div>';
	echo '<header class="sd-hd" id="sdHd"><div class="sd-wrap"><a class="sd-logo" href="' . esc_url(home_url('/')) . '" aria-label="Sublime Douceur, accueil"><span class="lg-ic">' . $ane . '</span><span class="lg-t">Sublime Douceur</span></a><nav class="sd-nav" aria-label="Principal">' . $links . '</nav><div class="sd-tools"><a class="ico acct" href="' . esc_url(wc_get_page_permalink('myaccount')) . '" aria-label="Mon compte"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg></a><button class="ico" id="sdCartB" aria-label="Panier"><svg viewBox="0 0 24 24"><path d="M5 8h14l-1.2 11.2a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg><span class="badge" id="sdCartN" hidden>0</span></button><button class="ico burger" id="sdBurger" aria-label="Menu"><svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h10"/></svg></button></div></div></header>';
	echo '<div class="sd-menu" id="sdMenu" aria-hidden="true"><div class="mtop"><span class="sd-logo"><span class="lg-ic">' . $ane . '</span><span class="lg-t">Sublime Douceur</span></span><button class="ico" id="sdMenuX" aria-label="Fermer"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div><nav>' . $links . '<a href="' . esc_url(wc_get_page_permalink('myaccount')) . '">Mon compte</a></nav></div>';
}, 5);
function sdd_ane() { return '<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 13c-1.5-4-2-8-.5-10 1.6 1.6 2.6 5 2.8 8.5M21 13c1.5-4 2-8 .5-10-1.6 1.6-2.6 5-2.8 8.5"/><path d="M10.5 15c0-3 2.4-4.5 5.5-4.5s5.5 1.5 5.5 4.5c0 2-1 3.5-1.5 5.5-.6 2.6-1.8 5-4 5s-3.4-2.4-4-5c-.5-2-1.5-3.5-1.5-5.5z"/><circle cx="13.5" cy="16" r=".6" fill="currentColor"/><circle cx="18.5" cy="16" r=".6" fill="currentColor"/><path d="M15 22.5h2"/></svg>'; }
add_action('wp_footer', function () {
	if (!sdd_on()) return;
	$h = 'esc_url';
	$ane = sdd_ane();
	if (!(function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page()))) { ?>
<section class="sd-lead"><div class="sd-wrap"><div><h2>Les 5 gestes qui assèchent la peau.</h2><p>Notre petit guide, offert, dans votre boîte e-mail. Puis deux ou trois conseils, pas plus. Désinscription en un clic.</p></div><form id="sdLeadF"><input name="prenom" placeholder="Prénom" autocomplete="given-name" aria-label="Prénom"><input name="email" type="email" required placeholder="Adresse e-mail" autocomplete="email" aria-label="Adresse e-mail"><input name="site" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true"><button class="sdd-btn">Recevoir le guide</button></form></div></section>
	<?php }
	?>
<div class="sd-wrap"><div class="sd-trust"><div><svg viewBox="0 0 24 24"><path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/></svg><div><b>Livraison offerte</b><span>dès 39 € en point relais</span></div></div><div><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg><div><b>3 à 5 jours ouvrés</b><span>expédié de Marseille</span></div></div><div><svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v4h4"/></svg><div><b>14 jours</b><span>pour changer d’avis</span></div></div><div><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg><div><b>Paiement sécurisé</b><span>carte bancaire, PayPal</span></div></div></div></div>
<footer class="sd-ft"><div class="sd-wrap"><div class="cols">
<div><div class="brand">Sublime Douceur</div><p>Savons de Marseille enrichis et soins au lait d’ânesse. Une question ? Nayette vous répond.</p><p style="margin-top:12px"><a href="mailto:contact@sublimedouceur.fr" style="display:inline;color:#fff">contact@sublimedouceur.fr</a></p></div>
<div><h4>Nos soins</h4><a href="<?php echo $h(home_url('/categorie-produit/lait-d-anesse/')); ?>">Lait d’ânesse</a><a href="<?php echo $h(home_url('/categorie-produit/savons/')); ?>">Savons enrichis</a><a href="<?php echo $h(home_url('/categorie-produit/soins/')); ?>">Soins du corps</a><a href="<?php echo $h(home_url('/categorie-produit/coffrets/')); ?>">Coffrets cadeaux</a><a href="<?php echo $h(home_url('/boutique/')); ?>">Tous les soins</a></div>
<div><h4>Aide</h4><a href="<?php echo $h(home_url('/livraison-retours/')); ?>">Livraison &amp; retours</a><a href="<?php echo $h(home_url('/faq/')); ?>">Questions fréquentes</a><a href="<?php echo $h(home_url('/contact/')); ?>">Contact</a><a href="<?php echo $h(home_url('/mon-compte/')); ?>">Mon compte</a></div>
<div><h4>Informations</h4><a href="<?php echo $h(home_url('/a-propos/')); ?>">Notre histoire</a><a href="<?php echo $h(home_url('/le-lait-d-anesse/')); ?>">Pourquoi le lait d’ânesse</a><a href="<?php echo $h(home_url('/guide-peaux-seches/')); ?>">Guide des peaux sèches</a><a href="<?php echo $h(home_url('/category/conseils-peau/')); ?>">Nos conseils</a><a href="<?php echo $h(home_url('/cgv/')); ?>">Conditions générales de vente</a><a href="<?php echo $h(home_url('/mentions-legales/')); ?>">Mentions légales</a><a href="<?php echo $h(home_url('/politique-de-confidentialite/')); ?>">Confidentialité</a></div>
</div><div class="legal"><span>© <?php echo date('Y'); ?> Sublime Douceur · Marseille</span><span>Ndeye Nayette Thiam · SIRET 449 613 686 00038</span></div></div></footer>
<div class="sd-ov" id="sdOv"></div>
<aside class="sd-drawer" id="sdDrawer" aria-label="Panier"><div class="dh"><h2 id="sdDrT">Votre panier</h2><button class="ico" id="sdDrX" aria-label="Fermer"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div><div class="db"><div class="prog" id="sdProg"></div><div id="sdLines"></div></div><div class="df" id="sdDf" hidden><div class="tot"><span>Sous-total</span><span id="sdSub"></span></div><small>Livraison et choix du point relais à l’étape suivante</small><a class="sdd-btn full" id="sdGo" href="<?php echo $h(wc_get_checkout_url()); ?>">Commander</a><a class="sd-link" style="text-align:center" href="<?php echo $h(wc_get_cart_url()); ?>">Voir le panier détaillé</a></div></aside>
<button class="sd-advb" id="sdAdvB" aria-label="Sublime Conseil, je vous aide à choisir"><span class="av"><?php echo $ane; ?></span><span><b>Sublime Conseil</b><small>Je vous aide à choisir</small></span></button>
<div class="sd-bub" id="sdBub" hidden><span>Un cadeau à trouver ? Je vous guide en 20 secondes.</span><button id="sdBubX" aria-label="Fermer"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
<section class="sd-adv" id="sdAdv" aria-label="Sublime Conseil"><div class="ah"><span class="av"><?php echo $ane; ?></span><div><b>Sublime Conseil</b><small>Je vous aide à choisir</small></div><button class="ico" id="sdAdvX" aria-label="Fermer"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div><div class="msgs" id="sdMsgs" aria-live="polite"></div><form class="advf" id="sdAdvF"><label class="sd-sr" for="sdAdvI">Message</label><input id="sdAdvI" autocomplete="off" placeholder="Écrivez votre question…"><button aria-label="Envoyer"><svg viewBox="0 0 24 24"><path d="M4 12l16-8-6 16-2-7z"/></svg></button></form></section>
<div class="sd-toast" id="sdToast" role="status"></div>
	<?php
}, 5);

/* ---------- Shortcodes ---------- */
add_shortcode('sd_home', function () {
	$r = sdd_p(36); ob_start(); ?>
<section class="sd-hero"><div class="sd-wrap"><div class="txt"><h1 class="deboss">Le savon de Marseille, adouci au lait d’ânesse.</h1><p class="lead">Savons surgras cuits à Marseille depuis 1949, soins au lait d’ânesse de Provence. Pour les peaux qui tiraillent.</p><div class="ctas"><button class="sdd-btn" data-quick="36">Offrir le Rituel · 39 €</button><button class="sdd-btn ghost" data-diag>Faire mon diagnostic peau</button></div><div class="facts"><span><svg viewBox="0 0 24 24"><path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/></svg>Livraison offerte dès 39 €</span><span><svg viewBox="0 0 24 24"><path d="M4 11h16v9H4zM3 7h18v4H3zM12 7v13"/></svg>Prêt à offrir</span><span><svg viewBox="0 0 24 24"><path d="M12 21s-6-5.5-6-10a6 6 0 0 1 12 0c0 4.5-6 10-6 10z"/><circle cx="12" cy="11" r="2"/></svg>Expédié de Marseille</span><span><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>Paiement sécurisé</span></div></div>
<div class="stamp"><div class="ring"></div><div class="oval"><video id="sdVid" autoplay muted loop playsinline preload="metadata" poster="<?php echo esc_url(SDD_URL . 'assets/ouverture.jpg'); ?>" aria-hidden="true"><source src="<?php echo esc_url(SDD_URL . 'assets/ouverture.mp4'); ?>" type="video/mp4"></video></div><div class="seal"><svg viewBox="0 0 132 132" aria-hidden="true"><defs><path id="sdcp" d="M66 66m-52 0a52 52 0 1 1 104 0a52 52 0 1 1-104 0"/></defs><text><textPath href="#sdcp" textLength="318" lengthAdjust="spacing">Savon de Marseille · lait d’ânesse · </textPath></text></svg><span>Depuis<b>1949</b></span></div></div></div></section>
<section class="sd-who sd-sec"><div class="sd-wrap"><h2>Pour qui est ce cadeau ?</h2><p class="lead">Choisissez, nous vous montrons le soin qui lui ressemble.</p><div class="chips" role="group"><?php foreach (['maman' => 'Ma maman', 'mamie' => 'Ma grand-mère', 'amie' => 'Une amie', 'soeur' => 'Ma sœur', 'homme' => 'Un homme', 'collegue' => 'Une collègue', 'moi' => 'Pour moi'] as $k => $l) echo '<button class="chip" data-who="' . $k . '" aria-pressed="' . ($k === 'maman' ? 'true' : 'false') . '">' . $l . '</button>'; ?></div><div class="pick" id="sdPick"></div></div></section>
<section class="sd-sec rv"><div class="sd-wrap"><h2>Trois gestes, matin et soir.</h2><p class="lead">Le rituel douceur, du visage au corps.</p><div class="rit"><?php foreach ([[15, 'Le visage', 'Faites mousser, massez, rincez à l’eau tiède.'], [27, 'La douche', 'Sous la douche, une mousse qui ne dessèche pas.'], [29, 'Le corps', 'Le lait corporel pénètre vite, sans effet gras.']] as $s) { $p = sdd_p($s[0]); if (!$p) continue; echo '<a class="step" href="' . esc_url($p['u']) . '"><div class="im"><img src="' . esc_url($p['i']) . '" alt="" loading="lazy"></div><span class="g">' . $s[1] . '</span><h3>' . esc_html($p['n']) . '</h3><p>' . $s[2] . ' <span class="pr">' . sdd_eur($p['p']) . '</span></p></a>'; } ?></div><div class="ritbar"><p>Avec le savon au lait d’ânesse, les quatre soins réunis dans leur barque : 39 €.</p><button class="sdd-btn" data-quick="36">Ajouter le Rituel</button></div></div></section>
<section class="sd-sec rv" style="padding-top:0"><div class="sd-wrap"><div class="head"><div><?php $pr = array_filter(array_map(function ($i) { $x = sdd_p($i); return $x ? $x['p'] : null; }, [36, 51, 150, 40, 49, 45])); ?><h2>Prêts à offrir, de <?php echo (int) floor(min($pr)); ?> à <?php echo (int) ceil(max($pr)); ?> €.</h2><p class="lead">Emballage cadeau inclus. Commandez avant le 16 décembre.</p></div><a class="sd-link" href="<?php echo esc_url(home_url('/categorie-produit/coffrets/')); ?>">Tous les coffrets</a></div><div class="rail"><?php foreach ([36, 51, 150, 40, 49, 45] as $id) echo sdd_card($id); ?></div></div></section>
<section class="sd-sec rv" style="padding-top:0"><div class="sd-wrap why"><div class="im"><img src="<?php echo esc_url(sdd_img('2026/10/img-hero-b.jpg')); ?>" alt="" loading="lazy"></div><div><h2>Pourquoi le lait d’ânesse ?</h2><p class="lead" style="margin-top:14px">Cléopâtre s’y baignait, dit la légende. Vingt siècles plus tard, il reste l’allié des peaux délicates.</p><div class="facts3"><div><i></i><b>Vitamines A, C et E</b><span>Avec minéraux et oligo-éléments, naturellement.</span></div><div><i></i><b>Oméga 3 et 6</b><span>Ils laissent la peau souple.</span></div><div><i></i><b>Une mousse onctueuse</b><span>Avec le savon surgras, la peau ne tiraille plus.</span></div></div><a class="sdd-btn ghost" href="<?php echo esc_url(home_url('/categorie-produit/lait-d-anesse/')); ?>">Découvrir la gamme</a><p class="note" style="margin-top:22px">Bienfaits traditionnellement associés au lait d’ânesse. Cosmétiques d’hygiène et de soin : ils ne remplacent pas un avis médical. Sur une peau réactive, faites d’abord un essai sur une petite zone.</p></div></div></section>
<section class="sd-sec rv"><div class="sd-wrap why"><div class="im"><img src="<?php echo esc_url(sdd_img('2026/11/rituel-salle-de-bain.jpg')); ?>" alt="Savon sur une vasque en pierre" loading="lazy" width="1080" height="1350"></div><div><h2>Le rituel, chez vous.</h2><p class="lead" style="margin-top:14px">Une mousse crémeuse, un lait qui pénètre vite. La peau reste souple, sans effet gras.</p><div class="facts3"><div><i></i><b>Le matin</b><span>Le savon surgras sous la douche, à l’eau tiède.</span></div><div><i></i><b>Juste après</b><span>Le lait corporel, sur une peau encore humide.</span></div><div><i></i><b>Le soir</b><span>Une noisette de karité sur les mains et les coudes.</span></div></div><p style="margin-top:26px"><button class="sdd-btn ghost" data-diag>Trouver ma routine</button></p></div></div></section>
<section class="sd-sec rv"><div class="sd-wrap story"><div class="big">1949</div><div><h2>Du chaudron marseillais à votre peau.</h2><p class="lead" style="margin:16px 0 26px">Nos savons et notre gel douche viennent de la Savonnerie Le Sérail, qui cuit son savon au chaudron à Marseille depuis 1949. Chacun est choisi par Nayette.</p><blockquote class="sd-quote"><p>« J’ai choisi chaque soin de cette gamme parce que je les utilise moi-même. Le savon du Sérail, cuit au chaudron à Marseille, et le lait d’ânesse : rien de plus, rien de superflu. Juste ce qu’il faut pour qu’une peau qui tiraille redevienne confortable. »</p><cite>Nayette</cite></blockquote><a class="sdd-btn ghost" href="<?php echo esc_url(home_url('/a-propos/')); ?>">Lire notre histoire</a></div></div></section>
	<?php return ob_get_clean();
});
add_shortcode('sd_gifts', function () {
	ob_start(); ?>
<section class="sd-sec" style="padding-bottom:0"><div class="sd-wrap"><h1>Idées cadeaux</h1><p class="lead" style="margin-top:12px">Commandé avant le 16 décembre, livré avant Noël.</p></div></section>
<section class="sd-who sd-sec"><div class="sd-wrap"><h2>Pour qui est ce cadeau ?</h2><div class="chips" role="group"><?php foreach (['maman' => 'Ma maman', 'mamie' => 'Ma grand-mère', 'amie' => 'Une amie', 'soeur' => 'Ma sœur', 'homme' => 'Un homme', 'collegue' => 'Une collègue', 'moi' => 'Pour moi'] as $k => $l) echo '<button class="chip" data-who="' . $k . '" aria-pressed="' . ($k === 'maman' ? 'true' : 'false') . '">' . $l . '</button>'; ?></div><div class="pick" id="sdPick"></div></div></section>
<section class="sd-sec"><div class="sd-wrap"><?php foreach ([['Moins de 20 €', 0, 19.99], ['De 20 à 40 €', 20, 40]] as $b) { echo '<h2 style="margin:0 0 22px">' . $b[0] . '</h2><div class="grid g4" style="margin-bottom:64px">'; foreach (sdd_products() as $p) if ($p['p'] >= $b[1] && $p['p'] <= $b[2]) echo sdd_card($p['id']); echo '</div>'; } ?></div></section>
	<?php return ob_get_clean();
});
add_shortcode('sd_milk', function () {
	ob_start(); ?>
<section class="sd-sec" style="padding-bottom:0"><div class="sd-wrap"><h1>Le lait d’ânesse</h1></div></section>
<section class="sd-sec" style="padding-top:20px"><div class="sd-wrap why"><div class="im"><img src="<?php echo esc_url(sdd_img('2026/11/soin-lait-epaule.jpg')); ?>" alt="" loading="lazy"></div><div><p class="lead">Cléopâtre s’y baignait, dit la légende. Vingt siècles plus tard, il reste l’allié des peaux délicates.</p><div class="facts3"><div><i></i><b>Vitamines A, C et E</b><span>Avec minéraux et oligo-éléments, naturellement.</span></div><div><i></i><b>Oméga 3 et 6</b><span>Ils laissent la peau souple.</span></div><div><i></i><b>Une mousse onctueuse</b><span>Avec le savon surgras, la peau ne tiraille plus.</span></div></div><p class="note">Bienfaits traditionnellement associés au lait d’ânesse. Cosmétiques d’hygiène et de soin : ils ne remplacent pas un avis médical. Sur une peau réactive, faites d’abord un essai sur une petite zone.</p></div></div></section>
<section class="sd-sec" style="padding-top:0"><div class="sd-wrap"><h2 style="margin-bottom:28px">La gamme lait d’ânesse</h2><div class="grid g4"><?php foreach (sdd_products() as $p) if (in_array('lait-d-anesse', $p['c'], true)) echo sdd_card($p['id']); ?></div></div></section>
	<?php return ob_get_clean();
});

/* ---------- Notices : pas de vieux « ajouté au panier » après le panier ou le paiement en blocs ---------- */
add_action('template_redirect', function () {
	if (!sdd_on() || !function_exists('wc_get_notices') || !(is_cart() || is_checkout())) return;
	$n = wc_get_notices(); if (isset($n['success'])) { unset($n['success']); wc_set_notices($n); }
});


/* ---------- Fiche produit : réassurance, questions, routine ---------- */
function sdd_kind($id) {
	$p = sdd_p($id); if (!$p) return '';
	$c = $p['c'];
	if (in_array('coffrets', $c, true)) return 'coffret';
	if ((int) $id === 27) return 'gel';
	if ((int) $id === 29) return 'lait';
	if ((int) $id === 31) return 'beurre';
	if (in_array('savons', $c, true)) return 'savon';
	return '';
}
add_action('woocommerce_after_add_to_cart_form', function () {
	global $product; if (!$product || !sdd_on()) return;
	$k = sdd_kind($product->get_id());
	$use = [
		'savon' => 'Faites-le mousser entre vos mains humides, massez, rincez à l’eau tiède. Entre deux usages, laissez-le sécher sur un porte-savon : il dure plus longtemps.',
		'gel' => 'Sous la douche, une noisette sur peau mouillée. Faites mousser, rincez.',
		'lait' => 'Après la douche, sur une peau encore légèrement humide. Massez jusqu’à ce qu’il pénètre : il ne laisse pas de film gras.',
		'beurre' => 'Une petite quantité, réchauffée entre les doigts, sur les zones très sèches : coudes, mains, talons.',
		'coffret' => 'Chaque soin s’utilise seul ou en routine : le savon ou le gel douche sous la douche, le lait corporel juste après.',
	];
	echo '<ul class="sd-pdp-trust"><li>Paiement sécurisé, carte ou PayPal</li><li>Livraison offerte dès 39 € en point relais</li><li>Expédié de Marseille en 3 à 5 jours ouvrés</li><li>14 jours pour changer d’avis</li></ul>';
	$skin = [13 => 'Toutes les peaux, pour une toilette douce au quotidien.', 15 => 'Les peaux sèches qui tiraillent après la douche.', 17 => 'Les peaux délicates, et toute la famille.', 19 => 'Les peaux qui manquent de confort : l’argan nourrit.', 21 => 'Les peaux sensibles ou facilement irritées.', 23 => 'Les peaux sèches, surtout en hiver.', 25 => 'Les peaux mixtes : la propolis purifie en douceur.', 27 => 'Toutes les peaux, pour celles qui préfèrent un soin liquide.', 29 => 'Les peaux sèches, juste après la douche.', 31 => 'Les peaux sèches à très sèches : mains, coudes, pieds, lèvres.'];
	$pid = (int) $product->get_id();
	echo '<div class="sd-faq">';
	if (isset($skin[$pid])) echo '<details open><summary>Pour quelle peau ?</summary><p>' . esc_html($skin[$pid]) . '</p></details>';
	if (isset($use[$k])) echo '<details><summary>Comment l’utiliser ?</summary><p>' . esc_html($use[$k]) . '</p></details>';
	echo '<details><summary>Convient-il aux peaux sensibles ?</summary><p>Nos soins au lait d’ânesse sont appréciés des peaux sèches et sensibles. Sur une peau réactive, faites d’abord un essai sur une petite zone. Ils ne remplacent pas un avis médical.</p></details>';
	if ($k === 'coffret') echo '<details><summary>Est-il prêt à offrir ?</summary><p>Oui : il arrive dans son emballage cadeau, prêt à être glissé sous le sapin.</p></details>';
	echo '<details><summary>Quand vais-je le recevoir ?</summary><p>Expédié de Marseille, livré en 3 à 5 jours ouvrés. Pour Noël, commandez avant le 16 décembre.</p></details>';
	echo '<details><summary>Puis-je le retourner ?</summary><p>Vous avez 14 jours après réception pour changer d’avis, sur les produits non ouverts.</p></details>';
	echo '</div>';
}, 20);
add_action('woocommerce_after_single_product_summary', function () {
	global $product; if (!$product || !sdd_on()) return;
	$id = (int) $product->get_id();
	$map = [13 => [29, 27, 36], 15 => [29, 27, 51], 17 => [29, 31, 40], 19 => [29, 31, 150], 21 => [27, 29, 40], 23 => [31, 29, 150], 25 => [27, 29, 40],
		27 => [29, 15, 49], 29 => [15, 27, 51], 31 => [23, 29, 150], 36 => [15, 31, 51], 51 => [13, 31, 36], 49 => [15, 31, 36], 45 => [29, 27, 36], 40 => [29, 31, 36], 150 => [31, 27, 40]];
	if (empty($map[$id])) return;
	$cards = ''; $ids = []; $tot = 0; foreach ($map[$id] as $r) { $c = sdd_card($r); if (!$c) continue; $cards .= $c; $pp = sdd_p($r); if ($pp && !$pp['v'] && !in_array($r, [SDD_PICK6, SDD_PICK1], true)) { $ids[] = $r; $tot += $pp['p']; } }
	if (!$cards) return;
	$bundle = '';
	if (in_array($id, [15, 27, 29], true) && ($l = sdd_p(51))) $bundle = '<div class="sd-bundle"><img src="' . esc_url($l['i']) . '" alt="" loading="lazy"><div><b>Souvent achetés ensemble</b><p>Savon surgras, gel douche et lait corporel réunis dans le lot Peaux sèches : ' . sdd_eur($l['p']) . ' au lieu de 33,00 €, en emballage cadeau.</p></div><button class="sdd-btn" data-quick="51">Ajouter le lot</button></div>';
	$all = count($ids) > 1 ? '<p style="margin-top:22px"><button class="sdd-btn ghost" data-addall="' . esc_attr(implode(',', $ids)) . '">Tout ajouter · ' . sdd_eur($tot) . '</button></p>' : '';
	echo '<section class="sd-sec sd-routine"><div class="sd-wrap">' . $bundle . '<h2>Complétez votre routine</h2><p class="lead">Les soins qui vont avec.</p><div class="grid g3">' . $cards . '</div>' . $all . '</div></section>';
}, 12);


add_action('woocommerce_single_product_summary', function () {
	global $product; if (!$product || !sdd_on() || (int) $product->get_id() !== 36) return;
	echo '<ul class="sd-badges"><li>Notre coffret le plus complet</li><li>Les 4 soins au lait d’ânesse</li><li>Peaux sèches et sensibles</li><li>Prêt à offrir</li><li>Livraison offerte</li></ul>';
}, 6);
/* ---------- Guide des peaux sèches ---------- */
add_shortcode('sd_guide', function () {
	$u = function ($f) { return esc_url(sdd_img('2026/11/' . $f)); };
	ob_start(); ?>
<section class="sd-sec" style="padding-bottom:0"><div class="sd-wrap why"><div class="im"><img src="<?php echo $u('guide-mousse-savon.jpg'); ?>" alt="Mousse de savon entre les mains" loading="eager" width="1080" height="1350"></div><div><h1>Peaux sèches et sensibles, le guide.</h1><p class="lead" style="margin-top:16px">Pourquoi la peau tiraille, les gestes qui l’aggravent, et la routine qui l’apaise.</p><p style="margin-top:22px"><button class="sdd-btn" data-diag>Faire mon diagnostic peau</button></p></div></div></section>
<section class="sd-sec"><div class="sd-wrap"><h2>Pourquoi la peau tiraille</h2><div class="facts3" style="margin-top:22px"><div><i></i><b>Le froid et le chauffage</b><span>L’air sec de l’hiver fait perdre à la peau son eau.</span></div><div><i></i><b>L’eau calcaire</b><span>Très présente dans le Sud, elle laisse un film qui dessèche.</span></div><div><i></i><b>Les nettoyants trop décapants</b><span>Ils emportent aussi le film protecteur de la peau.</span></div></div></div></section>
<section class="sd-sec" style="padding-top:0"><div class="sd-wrap"><h2>Les 5 gestes qui assèchent, sans qu’on y pense</h2><ol class="sd-steps"><li><b>La douche trop chaude.</b> Préférez une eau tiède.</li><li><b>La douche trop longue.</b> Cinq minutes suffisent.</li><li><b>Frotter avec la serviette.</b> Tamponnez plutôt.</li><li><b>Attendre pour hydrater.</b> Le lait corporel s’applique dans les minutes qui suivent.</li><li><b>Changer de soin trop souvent.</b> La peau aime la constance.</li></ol></div></section>
<section class="sd-sec" style="padding-top:0"><div class="sd-wrap why"><div class="im"><img src="<?php echo $u('guide-routine-lin.jpg'); ?>" alt="Routine de soin sur du lin" loading="lazy" width="1080" height="1350"></div><div><h2>La routine en deux gestes</h2><p class="lead" style="margin-top:14px">Un savon qui lave sans dessécher, un lait qui garde l’eau dans la peau.</p><div class="grid g2" style="margin-top:26px"><?php echo sdd_card(15) . sdd_card(29); ?></div><p style="margin-top:18px">Ou les trois soins réunis, 2 € de moins qu’à l’unité :</p><div class="grid g2" style="margin-top:14px"><?php echo sdd_card(51); ?></div></div></div></section>
<section class="sd-sec" style="padding-top:0"><div class="sd-wrap why"><div class="im"><img src="<?php echo $u('guide-lait-corps.jpg'); ?>" alt="Lait corporel appliqué sur le bras" loading="lazy" width="1080" height="1350"></div><div><h2>Vos questions</h2><div class="sd-faq" style="margin-top:18px"><details><summary>Savon surgras ou gel douche ?</summary><p>Le savon surgras garde une part d’huiles non transformées : il lave en douceur. Le gel douche plaît à celles qui préfèrent une texture liquide. Pour une peau très sèche, le savon surgras est le plus doux.</p></details><details><summary>Pourquoi le lait d’ânesse ?</summary><p>Il apporte naturellement des vitamines A, C et E et des acides gras. On l’associe depuis l’Antiquité aux soins des peaux délicates.</p></details><details><summary>Et pour une peau mature ?</summary><p>Le savon à l’huile d’argan, puis le lait corporel au lait d’ânesse : une routine simple, matin et soir.</p></details><details><summary>J’ai de l’eczéma, puis-je les utiliser ?</summary><p>Ce sont des cosmétiques, pas des traitements. Demandez d’abord l’avis de votre médecin, puis faites un essai sur une petite zone.</p></details></div></div></div></section>
	<?php return ob_get_clean();
});

/* ---------- Choix des savons dans les coffrets ---------- */
function sdd_soap_names() { $o = []; foreach (SDD_SOAPS as $id) { $p = sdd_p($id); if ($p) $o[$id] = $p; } return $o; }
add_action('woocommerce_before_add_to_cart_button', function () {
	global $product; if (!$product || !sdd_on()) return;
	$id = $product->get_id();
	if ($id !== SDD_PICK6 && $id !== SDD_PICK1) return;
	$soaps = sdd_soap_names();
	if ($id === SDD_PICK6) {
		echo '<div class="sd-opt" id="sdSix" hidden><span>Choisissez vos 6 savons</span><div class="soaps">';
		foreach ($soaps as $sid => $p) echo '<div class="soap" data-six="' . $sid . '"><img src="' . esc_url($p['i']) . '" alt=""><span>' . esc_html($p['n']) . '</span><span class="q"><button type="button" data-s6="-' . $sid . '" aria-label="Retirer">−</button><b id="s6' . $sid . '">0</b><button type="button" data-s6="+' . $sid . '" aria-label="Ajouter">+</button></span></div>';
		echo '</div><p class="cnt" id="sdCnt"></p><input type="hidden" name="sdd_six" id="sdd_six" value=""></div>';
	} else {
		echo '<div class="sd-opt"><span>Votre savon enrichi</span><div class="soaps">';
		foreach ($soaps as $sid => $p) { if ($sid === 13) continue; echo '<button type="button" class="soap' . ($sid === 17 ? ' on' : '') . '" data-one="' . $sid . '"><img src="' . esc_url($p['i']) . '" alt=""><span>' . esc_html($p['n']) . '</span></button>'; }
		echo '</div><input type="hidden" name="sdd_one" id="sdd_one" value="17"></div>';
	}
});
function sdd_is_choose_variation($variation_id) {
	if (!$variation_id) return false;
	$v = wc_get_product($variation_id); if (!$v) return false;
	foreach ($v->get_attributes() as $val) if (stripos((string) $val, 'choisi') !== false) return true;
	return false;
}
add_filter('woocommerce_add_to_cart_validation', function ($ok, $pid, $qty, $vid = 0) {
	if (sdd_on() && (int) $pid === SDD_PICK6 && sdd_is_choose_variation($vid)) {
		$six = isset($_POST['sdd_six']) ? sanitize_text_field(wp_unslash($_POST['sdd_six'])) : '';
		$n = 0; foreach (array_filter(explode(',', $six)) as $part) { $x = explode('x', $part); $n += (int) ($x[1] ?? 0); }
		if ($n !== 6) { wc_add_notice('Choisissez vos 6 savons avant d’ajouter le coffret au panier.', 'error'); return false; }
	}
	return $ok;
}, 10, 4);
add_filter('woocommerce_add_cart_item_data', function ($data, $pid, $vid) {
	$soaps = sdd_soap_names();
	if ((int) $pid === SDD_PICK6 && sdd_is_choose_variation($vid) && !empty($_POST['sdd_six'])) {
		$txt = [];
		foreach (array_filter(explode(',', sanitize_text_field(wp_unslash($_POST['sdd_six'])))) as $part) { $x = explode('x', $part); $sid = (int) $x[0]; $q = (int) ($x[1] ?? 0); if ($q > 0 && isset($soaps[$sid])) $txt[] = $q . ' × ' . $soaps[$sid]['n']; }
		if ($txt) $data['sdd_soaps'] = implode(', ', $txt);
	}
	if ((int) $pid === SDD_PICK1 && !empty($_POST['sdd_one'])) {
		$sid = (int) $_POST['sdd_one']; if (isset($soaps[$sid])) $data['sdd_soaps'] = $soaps[$sid]['n'];
	}
	if (!empty($data['sdd_soaps'])) $data['sdd_key'] = md5($data['sdd_soaps']);
	return $data;
}, 10, 3);
add_filter('woocommerce_get_item_data', function ($d, $item) {
	if (!empty($item['sdd_soaps'])) $d[] = ['key' => 'Savons choisis', 'value' => $item['sdd_soaps']];
	return $d;
}, 10, 2);
add_action('woocommerce_checkout_create_order_line_item', function ($line, $key, $values) {
	if (!empty($values['sdd_soaps'])) $line->add_meta_data('Savons choisis', $values['sdd_soaps']);
}, 10, 3);
